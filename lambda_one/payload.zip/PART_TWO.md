# Challenge Part Two

## Description

Part two of the challenge includes obtaining data from an API and saving this to an s3 bucket as a JSON file.

## Next Steps

Additional work would include putting the JSON file in a prefix-ed subdirectory of the s3 bucket. This would ensure that the process that syncs bls.gov data to the bucket does not attempt to process the JSON data and compare this to the bls.gov data.
